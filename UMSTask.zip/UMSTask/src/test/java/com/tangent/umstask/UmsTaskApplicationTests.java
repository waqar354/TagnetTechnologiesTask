package com.tangent.umstask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmsTaskApplicationTests {

    @Test
    void contextLoads() {
    }

}
