package com.tangent.umstask.controller;

import com.tangent.umstask.model.*;
import com.tangent.umstask.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Controller {
    @Autowired
    AdminServ adminService;
    @Autowired
    CourseServ courseService;
    @Autowired
    RegisterCourseServ registerCourseService;
    @Autowired
    SemesterServ semesterService;
    @Autowired
    StudentServ studentService;
    @Autowired
    TeacherServ teacherService;
    @Autowired
    UserServ userService;

    @GetMapping("/")
    public String welcomeText(){
        return "Welcome to the University Management System";
    }

    @PostMapping("/addNewStudent")
    public Student newStudent(@RequestBody GetUserType userType){
        User user = userService.addNewUser(userType.getUser());
        userType.getStudent().setStudentId(user.getUserId());
        return studentService.newStudent(userType.getStudent());
    }

    @PostMapping("/addNewTeacher")
    public Teacher addTeacher(@RequestBody GetUserType userType){
        User user = userService.addNewUser(userType.getUser());
        userType.getTeacher().setTeacherId(user.getUserId());
        return teacherService.newTeacher(userType.getTeacher());
    }

    @PostMapping("/addNewAdmin")
    public Admin addAdmin(@RequestBody GetUserType userType){
        User user = userService.addNewUser(userType.getUser());
        userType.getAdmin().setAdminId(user.getUserId());
        return adminService.newAdmin(userType.getAdmin());
    }

    @PostMapping("/addNewSemester")
    public Semester addSemester(@RequestBody Semester newSemester){
        return semesterService.addNewSemester(newSemester);
    }

    @GetMapping("/coursesOffered")
    public List<Course> coursesOffered(@RequestParam String semesterId){
        return courseService.coursesInSemester(semesterId);
    }

    @PostMapping("/courseRegistration")
    public String registerCourses(@RequestBody RegisterCourse registerCourse){
        if(registerCourseService.totalNumberOfCourses(registerCourse.getStudentId())<5)
            return "Registered Successfully!";
        else
            return "Sorry! Student's course limit exceeds 5.";
    }

    @PostMapping("/courseTeacherAssignment")
    public String addStudent(@RequestBody Course course){

        if(courseService.totalNumberOfCourses(course.getTeacherId())<3)
            return "Assigned Successfully!";
        else
            return "Sorry! Teacher's course limit exceeds 3.";
    }

}
