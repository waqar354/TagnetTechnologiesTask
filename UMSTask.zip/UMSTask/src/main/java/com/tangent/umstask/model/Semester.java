package com.tangent.umstask.model;

import javax.persistence.*;

@Entity
public class Semester {
    @Id
    String semesterId;

    @Column(name = "type")
    String type;
    @Column(name = "duration")
    Integer duration;

    public Semester() {
    }

    public Semester(String semesterId, String type, Integer duration) {
        this.semesterId = semesterId;
        this.type = type;
        this.duration = duration;
    }

    public String getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(String semesterId) {
        this.semesterId = semesterId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }
}
