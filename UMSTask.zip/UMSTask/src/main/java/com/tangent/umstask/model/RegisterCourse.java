package com.tangent.umstask.model;

import javax.persistence.*;

@Entity
public class RegisterCourse {

    @Id
    String id;

    @Column(name = "courseId")
    String courseId;
    @Column(name = "studentId")
    String studentId;

    public RegisterCourse() {
    }

    public RegisterCourse(String id, String courseId, String studentId) {
        this.id = id;
        this.courseId = courseId;
        this.studentId = studentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String course_id) {
        this.courseId = course_id;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String student_id) {
        this.studentId = student_id;
    }
}
