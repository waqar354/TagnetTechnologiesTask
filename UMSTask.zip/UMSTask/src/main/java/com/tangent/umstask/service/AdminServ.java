package com.tangent.umstask.service;

import com.tangent.umstask.model.Admin;
import com.tangent.umstask.repository.AdminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServ {
    @Autowired
    AdminRepo adminRepository;

    public Admin newAdmin(Admin admin){
        return adminRepository.save(admin);
    }
}
