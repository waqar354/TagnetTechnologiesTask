package com.tangent.umstask.service;

import com.tangent.umstask.model.Student;
import com.tangent.umstask.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServ {
    @Autowired
    StudentRepo studentRepository;

    public Student newStudent(Student newStudent){
        return studentRepository.save(newStudent);
    }
}
