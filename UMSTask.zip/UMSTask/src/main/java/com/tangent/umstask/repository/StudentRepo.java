package com.tangent.umstask.repository;

import com.tangent.umstask.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepo extends JpaRepository<Student, String> {
}
