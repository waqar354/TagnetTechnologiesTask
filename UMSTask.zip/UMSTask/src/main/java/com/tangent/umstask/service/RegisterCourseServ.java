package com.tangent.umstask.service;

import com.tangent.umstask.model.RegisterCourse;
import com.tangent.umstask.repository.RegisterCourseRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterCourseServ {
    @Autowired
    RegisterCourseRepo registerCourseRepository;

    public RegisterCourse enrollCourse(RegisterCourse newRegisterCourse){
        return registerCourseRepository.save(newRegisterCourse);
    }
    public Integer totalNumberOfCourses(String studentId){
        return registerCourseRepository.getAllByStudentId(studentId).size();
    }
}
