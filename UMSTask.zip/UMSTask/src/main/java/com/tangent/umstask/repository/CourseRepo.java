package com.tangent.umstask.repository;

import com.tangent.umstask.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepo extends JpaRepository<Course, String> {
    public List<Course> getAllByTeacherId(String teacher_id);
    public List<Course> getAllBySemester(String semester_id);
}
