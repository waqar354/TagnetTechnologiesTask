package com.tangent.umstask.service;

import com.tangent.umstask.model.Semester;
import com.tangent.umstask.repository.SemesterRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SemesterServ {
    @Autowired
    SemesterRepo semesterRepository;

    public Semester addNewSemester(Semester newSemester){
        return semesterRepository.save(newSemester);
    }
}
