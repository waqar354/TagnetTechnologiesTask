package com.tangent.umstask.service;

import com.tangent.umstask.model.User;
import com.tangent.umstask.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServ {
    @Autowired
    UserRepo userRepository;

    public User addNewUser(User newUser){
        return userRepository.save(newUser);
    }
}
