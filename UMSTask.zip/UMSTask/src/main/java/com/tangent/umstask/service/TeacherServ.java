package com.tangent.umstask.service;

import com.tangent.umstask.model.Teacher;
import com.tangent.umstask.repository.TeacherRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherServ {
    @Autowired
    TeacherRepo teacherRepository;

    public Teacher newTeacher(Teacher newTeacher){
        return teacherRepository.save(newTeacher);
    }
}
