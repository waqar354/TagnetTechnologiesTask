package com.tangent.umstask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmsTaskApplication {

    public static void main(String[] args) {
        SpringApplication.run(UmsTaskApplication.class, args);
    }

}
