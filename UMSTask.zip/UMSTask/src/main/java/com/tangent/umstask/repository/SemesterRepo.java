package com.tangent.umstask.repository;

import com.tangent.umstask.model.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SemesterRepo extends JpaRepository<Semester, String> {

}
