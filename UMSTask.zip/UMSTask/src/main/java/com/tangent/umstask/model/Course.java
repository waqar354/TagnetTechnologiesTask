package com.tangent.umstask.model;

import javax.persistence.*;

@Entity
public class Course {
    @Id
    String course_id;

    @Column(name = "name")
    String name;
    @Column(name = "description")
    String description;
    @Column(name = "creditHours")
    Integer creditHours;
    @Column(name = "semester_id")
    String semester;
    @Column(name = "teacher_id")
    String teacherId;

    public Course() {
    }

    public Course(String course_id, String name, String description, Integer creditHours, String semester, String teacherId) {
        this.course_id = course_id;
        this.name = name;
        this.description = description;
        this.creditHours = creditHours;
        this.semester = semester;
        this.teacherId = teacherId;
    }

    public String getCourse_id() {
        return course_id;
    }

    public void setCourse_id(String course_id) {
        this.course_id = course_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(Integer creditHours) {
        this.creditHours = creditHours;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String courseId) {
        this.semester = courseId;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }
}
