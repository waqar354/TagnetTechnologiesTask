package com.tangent.umstask.service;

import com.tangent.umstask.model.Course;
import com.tangent.umstask.repository.CourseRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServ {
    @Autowired
    CourseRepo courseRepository;

    public Course newCourse(Course newCourse){
        return courseRepository.save(newCourse);
    }

    public Integer totalNumberOfCourses(String teacherId){
        return courseRepository.getAllByTeacherId(teacherId).size();
    }

    public List<Course> coursesInSemester(String semester_id){
        return courseRepository.getAllBySemester(semester_id);
    }
}
