package com.tangent.umstask.repository;

import com.tangent.umstask.model.RegisterCourse;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RegisterCourseRepo extends JpaRepository<RegisterCourse,String> {
    public List<RegisterCourse> getAllByStudentId(String student_id);
}
